package com.book.domain.repository;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.book.domain.model.Guestbook;

@Repository
public class GuestbookRepository {
	
	@PersistenceContext 	// EntityManagerFactory가 DI 할 수 있도록 어노테이션 설정
	private EntityManager em;
	
	//찾기
	public List<Guestbook> findAll(){

		String jpql = "SELECT gb FROM Guestbook gb";
		
		TypedQuery<Guestbook> query = em.createQuery(jpql, Guestbook.class);
		
		return query.getResultList();
	}
	
	
	//저장
	//persist는 영속화 시킨다는 의미인데 정확히는 데이터를 추가하는 것이 아니지만, 
	//편의상 INSERT 쿼리가 수행되므로 데이터를 추가하는 메서드라 표현.
	public void save(Guestbook guestbook) {
		em.persist(guestbook);
	}
	
	
	
	//삭제
	public boolean remove(Guestbook guestbook) {
		String jpql = "SELECT gb from Guestbook gb WHERE gb.no = :no AND gb.pwd = :pwd";
		TypedQuery<Guestbook> query = em.createQuery(jpql, Guestbook.class);
		query.setParameter("no", guestbook.getNo());
		query.setParameter("pwd", guestbook.getPwd());

		List<Guestbook> guestbookList = query.getResultList();
		if( guestbookList.size() != 1 ) {
			return false;
		}
		
		em.remove(guestbookList.get(0));
		return true;
	}
	
}
