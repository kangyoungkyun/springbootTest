package com.book.domain.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="guestbook")
public class Guestbook {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer no;
	
	@Column(name="name", nullable=false, length=100)
	private String name;
	
	@Column(name="pwd", nullable=false, length=64)
	private String pwd;

	@Column(name="message", nullable=false)
	private String message;
	
	//@Temporal(TemporalType.TIMESTAMP)
//	@Column(name="reg_date", nullable=false)
//	private Date regDate;

	
	
	

	public Integer getNo() {
		return no;
	}





	public void setNo(Integer no) {
		this.no = no;
	}





	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	public String getPwd() {
		return pwd;
	}





	public void setPwd(String pwd) {
		this.pwd = pwd;
	}





	public String getMessage() {
		return message;
	}





	public void setMessage(String message) {
		this.message = message;
	}





//	public Date getRegDate() {
//		return regDate;
//	}
//
//
//
//
//
//	public void setRegDate(java.util.Date date) {
//		this.regDate = (Date) date;
//	}


	//기본생성자
	public Guestbook() {
		super();
	}

	

	public Guestbook(Integer no, String name, String pwd, String message) {
		super();
		this.no = no;
		this.name = name;
		this.pwd = pwd;
		this.message = message;
		
	}

	
}