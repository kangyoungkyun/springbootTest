package com.book.domain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GustbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(GustbookApplication.class, args);
		
		System.out.println("Guestbook start!");
	}

}
