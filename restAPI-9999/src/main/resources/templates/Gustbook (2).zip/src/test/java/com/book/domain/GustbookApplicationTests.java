package com.book.domain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GustbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
