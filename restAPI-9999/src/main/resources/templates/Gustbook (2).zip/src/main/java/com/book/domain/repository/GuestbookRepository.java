package com.book.domain.repository;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.book.domain.model.GuestBookDTO;
import com.book.domain.model.Guestbook;

@Repository
public class GuestbookRepository {
	
	@PersistenceContext 	// EntityManagerFactory가 DI 할 수 있도록 어노테이션 설정
	private EntityManager em;
	
	//찾기
	public List<Guestbook> findAll(){
		
		/*
		
		//TypedQuery
		
		//1.jpql 엔티티와 속성은 대소문자를 구분합니다.
		//2.JPQL에서 엔티티의 별칭은 필수적으로 명시해야 합니다.
		//별칭을 명시하는 AS 키워드는 생략할 수 있습니다.
		//여러 개의 칼럼을 선택적으로 명시한 후, TypedQuery를 선언하면 에러가 발생
		String jpql = "SELECT gb FROM Guestbook gb";
		
		//EntityManager 객체에서 createQuery() 메서드를 호출하면 쿼리가 생성됩니다.
		//TypedQuery는 반환되는 엔티티가 정해져 있을 때 사용하는 타입이며,
		TypedQuery<Guestbook> query = em.createQuery(jpql, Guestbook.class);
		
	
		//TypedQuery 객체의 getResultList() 메서드를 호출하면 작성한 JPQL에 의해 데이터를 검색하며, List 타입으로 반환합니다.
		List<Guestbook>	guestbookList = query.getResultList();
		
		for (Guestbook guestbook : guestbookList) {
			System.out.println("이름 :" + guestbook.getName());
		}
		
		*/
		
		
		
		
		/*
		
		//Query
		List<Guestbook>	guestbookList2 = new ArrayList<Guestbook>();
		
		//변수 jpql에서 SELECT 하는 칼럼을 선택적으로 명시한 점을 주목해주세요. Query 타입을 사용하면 이런 식으로 여러 개의 칼럼을 선택적으로 명시할 수 있습니다.
		//중요한건 리턴 타입이 없다!  
		 
		String queryText = "SELECT g.id , g.name, g.message, g.pwd FROM Guestbook g";
		
		Query queryTest = em.createQuery(queryText);
		
		List<Object> list = queryTest.getResultList();
		//TypedQuery와 달리 Query 타입은 데이터 검색 결과의 타입을 명시하지 않습니다.그래서 List의 제네릭 타입으로 Object를 작성했습니다.
		for (Object object : list) {
			
			Object[] results = (Object[]) object;
			
			 for( Object result : results ) {
		          System.out.print ( result );
		     }
		     System.out.println();
		}
		*/
		
		
		/*
		
		//파라미터가 있을때  
		
		String sqlTestTwo =  "SELECT gb FROM Guestbook gb WHERE gb.id = :foo";
		TypedQuery<Guestbook> guestbookquery = em.createQuery(sqlTestTwo, Guestbook.class);
		guestbookquery.setParameter("foo", 1);
		
		List<Guestbook> guestbooklists = guestbookquery.getResultList();
		for (Guestbook guestbook : guestbooklists) {
			System.out.println(guestbook.getName());
		}
		
		*/
		
		

		
		return  null;
		
		
		//return queryTest.getResultList();
	}
	
	
	
	//dto 로 찾기
	public List<GuestBookDTO> findAllByDTO(){
		//new 키워드 뒤에 DTO의 패키지명까지 작성해야 한다는 것에 주의
		//BookDTO에서 생성자를 오버로딩한 이유는 위와 같이 JPQL을 작성하기 위함
		//즉 BookDTO 객체 필드 값으로 쿼리의 결과 값을 할당합니다.
		
		String sqlbydto = "SELECT new com.book.domain.model.GuestBookDTO(g.no, g.name, g.message, g.pwd) FROM Guestbook g";
		TypedQuery<GuestBookDTO>  dtoquery = em.createQuery(sqlbydto, GuestBookDTO.class);
		List<GuestBookDTO>	list= dtoquery.getResultList();
		for (GuestBookDTO guestBookDTO : list) {
			System.out.println(guestBookDTO.getName());
		}
		
		return list;
	
	}
	
	
	
	
	/*
	 
	 유사 검색

	String jpql = "select b from Board b where b.title LIKE CONCAT('%',:kwd,'%') ";
	  
	  
	 */
	
	
	
	
	//저장
	//persist는 영속화 시킨다는 의미인데 정확히는 데이터를 추가하는 것이 아니지만, 
	//편의상 INSERT 쿼리가 수행되므로 데이터를 추가하는 메서드라 표현.
	public void save(Guestbook guestbook) {
		em.persist(guestbook);
	}
	
	
	
	//삭제
	public boolean remove(Guestbook guestbook) {
		String jpql = "SELECT gb from Guestbook gb WHERE gb.no = :no AND gb.pwd = :pwd";
		TypedQuery<Guestbook> query = em.createQuery(jpql, Guestbook.class);
		query.setParameter("no", guestbook.getNo());
		query.setParameter("pwd", guestbook.getPwd());

		List<Guestbook> guestbookList = query.getResultList();
		if( guestbookList.size() != 1 ) {
			return false;
		}
		
		em.remove(guestbookList.get(0));
		return true;
	}
	
}
