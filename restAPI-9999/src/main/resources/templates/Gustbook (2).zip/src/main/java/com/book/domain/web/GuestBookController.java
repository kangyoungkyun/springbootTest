package com.book.domain.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.book.domain.model.GuestBookDTO;
import com.book.domain.model.Guestbook;
import com.book.domain.model.User;
import com.book.domain.service.GuestbookService;

@Controller
@RequestMapping("")
public class GuestBookController {

	
	@Autowired
	private GuestbookService guestbookService;
	
	//삭제
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String deleteform() {
		return "guestbook/deleteform";
	}


	@RequestMapping(value="/delete", method=RequestMethod.POST)
	public String delete(Guestbook guestbook) {
		guestbookService.deleteMessage( guestbook );
		return "redirect:/";
	}
	
	
	//삽입
	@RequestMapping(value="/guestbook", method=RequestMethod.POST)
	public String add(Guestbook guestbook) {
		guestbookService.insertMessage(guestbook);
		return "redirect:/dto";
	}
	
	
	//조회
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String index(Model model) {
		List<Guestbook> guestbookList = guestbookService.getMessageList();
		model.addAttribute("guestbookList", guestbookList);
		return "guestbook/index";
	}
	
	
	//조회
	@RequestMapping(value="/dto", method=RequestMethod.GET)
	public String indexDTO(Model model) {
		
		List<GuestBookDTO> guestbookList = guestbookService.getMessageListByDTO();
		
		model.addAttribute("guestbookList", guestbookList);
		
		return "guestbook/index";
	}
	
	
	//테스트
	@GetMapping("/test")
	public String main(Model model) {
		System.out.println("/main");
		User user = new User("abcnt", "kyk", "web");
		model.addAttribute("user", user);
		return "guestbook/test";
	}
	
	
	
}
