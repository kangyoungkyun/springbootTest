package com.book.domain.service;


import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.domain.model.GuestBookDTO;
import com.book.domain.model.Guestbook;
import com.book.domain.repository.GuestbookRepository;


/*
 Service 계층에서 주의해야 할 점이 있습니다.

INSERT , UPDATE , DELETE 쿼리를 수행 할 때는 트랜잭션을 필수적으로 명시를 해줘야 합니다.

JPA는 트랜잭션을 제공하기 때문에 클래스 선언부 위에 @Transactional 어노테이션을 추가해야 합니다.
 */
@Transactional
@Service
public class GuestbookService {
	@Autowired
	private GuestbookRepository guestbookRepository;
	
	//조회
	public List<Guestbook> getMessageList(){
		return guestbookRepository.findAll();
	}
	
	
	//조회 - DTO
	public List<GuestBookDTO> getMessageListByDTO(){
		return guestbookRepository.findAllByDTO();
	}
	
	//저장
	public void insertMessage(Guestbook guestbook) {
		//guestbook.setRegDate(new Date());
		guestbookRepository.save(guestbook);
	}
	
	//삭제
	public void deleteMessage(Guestbook guestbook) {
		boolean result = guestbookRepository.remove(guestbook);
	}
	
}
