package com.book.domain.model;

import javax.persistence.Column;

public class GuestBookDTO {

	

	private Integer no;
	
	private String name;

	
	private String pwd;

	
	private String message;
	
	
	
	public GuestBookDTO() {

	}


	public GuestBookDTO(Integer no, String name, String pwd, String message) {
		super();
		this.no = no;
		this.name = name;
		this.pwd = pwd;
		this.message = message;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getNo() {
		return no;
	}

	public String getName() {
		return name;
	}

	public void setNo(Integer no) {
		this.no = no;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	@Override
	public String toString() {
		return "GuestBookDTO [no=" + no + ", name=" + name + ", pwd=" + pwd + ", message=" + message + "]";
	}

	
	
}
