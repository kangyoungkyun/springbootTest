package com.book.domain.repository;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.book.domain.model.Guestbook;
import com.book.domain.model.QGuestbook;
import com.mysema.query.jpa.impl.JPAQuery;

//참고 : https://victorydntmd.tistory.com/206?category=698080

/*

 pom.xml 에 추가!
 
	<!-- queryDSL -->
	
	<dependency>
	
	        <groupId>com.mysema.querydsl</groupId>
	
	        <artifactId>querydsl-jpa</artifactId>
	
	        <version>3.6.2</version>
	
	</dependency>
	
	
	
	<dependency>
	
	        <groupId>com.mysema.querydsl</groupId>
	
	        <artifactId>querydsl-apt</artifactId>
	
	        <version>3.6.2</version>
	
	        <scope>provided</scope>
	
	</dependency>


	<plugin>

         <groupId>com.mysema.maven</groupId>

         <artifactId>apt-maven-plugin</artifactId>

         <version>1.0.9</version>

         <executions>

                  <execution>

                           <goals>

                                   <goal>process</goal>

                           </goals>

                           <configuration>

                                   <outputDirectory>target/generated-sources/java</outputDirectory>

                                   <processor>com.mysema.query.apt.jpa.JPAAnnotationProcessor</processor>

                           </configuration>

                  </execution>

         </executions>

</plugin>







*/


@Repository
public class GuestbookRepositoryByQueryDSL {
	@PersistenceContext 	// EntityManagerFactory가 DI 할 수 있도록 어노테이션 설정
	private EntityManager em;
	
	
	public List<Guestbook> findAllByQueryDSL(){
		
		JPAQuery query = new JPAQuery(em);
		//QGuestbook 클래스를 열어보시면, static으로 미리 QGuestbook 객체를 guestbook이라는 변수로 만들어 놓았다.
		QGuestbook qguestbook = new QGuestbook("guestbook");
		
		List<Guestbook> guestbookList = query
											  .from(qguestbook)
											  .list(qguestbook);	//조회 결과를 리스트로 반환
		return guestbookList;
	}
	
	
	
	public void saveByQueryDSL(Guestbook guestbook) {
		em.persist(guestbook);
	}

	
	
	public boolean removeByQueryDSL(Guestbook paramGuestbook) {
		JPAQuery query = new JPAQuery(em);
		//QGuestbook 클래스를 열어보시면, static으로 미리 QGuestbook 객체를 guestbook이라는 변수로 만들어 놓았다.
		QGuestbook guestbook = new QGuestbook("guestbook");
		List<Guestbook> guestbookList
						= query.from(guestbook)
									.where(guestbook.no.eq(paramGuestbook.getNo())
									.and(guestbook.pwd.eq(paramGuestbook.getPwd())))
									.list(guestbook);
		if( guestbookList.size() != 1 ) {
			return false;
		}
		
		em.remove(guestbookList.get(0));
		return true;
	}
}




/*







1. SELECT
1) where and
List<Book> bookList
				= query.from(book)
							.where(book.title.eq("토비의 스프링")
							.and(book.price.lt(50000)))
							.list(book);

List<Book> bookList
				= query.from(book)
							.where(book.title.eq("토비의 스프링"), book.price.lt(50000))
							.list(book);


and는 콤마(,)로 대체가 가능합니다.



2) where between
List<Book> bookList
				= query.from(book)
							.where(book.price.between(15000, 18000))
							.list(book);





3) where contains

List<Book> bookList
				= query.from(book)
							.where(book.title.contains("리눅스"))
							.list(book);



4) where startsWith

List<Book> bookList
				= query.from(book)
							.where(book.title.startsWith("토비"))
							.list(book);





DTO 사용하기 - Projections.bean()

// as를 통해 별칭을 줄 수도 있다.
List<BookDTO> list
				= query.from(book)
							.list(Projections.bean(BookDTO.class, book.no.as("no"), book.title));


DTO 사용하기 - Projections.fields()

List<BookDTO> list
				= query.from(book)
							.list(Projections.fields(BookDTO.class, book.no.as("no"), book.title));
Projections.bean() 메서드는 DTO의 setter를 사용해서 값을 세팅하는 반면,

Projections.fields() 메서드는 setter가 없어도 값을 세팅합니다.





DTO 사용하기 - Projections.constructor()

List<BookDTO> list
				= query.from(book)
							.list(Projections.constructor(BookDTO.class, book.no.as("no"), book.title));
DTO의 생성자를 호출 하는 방법입니다.

이 때 DTO 클래스에는 프로젝션의 순서와 일치하는 생성자가 오버로딩 되어 있어야 합니다.


 */
